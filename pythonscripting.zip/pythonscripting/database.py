#!/usr/bin/python
var=123
name="sai"
print "value of variable is",var 
print "name is",name

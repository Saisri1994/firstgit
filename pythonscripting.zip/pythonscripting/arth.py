#!/usr/bin/python
"""python comparision operators"""
"""
a=10
b=20
if (a==b):
 print "a equal to b"
else:
 print "a not equal ro b "
if (a!=b):
 print "a not equal to b"
else:
 print "a equal"

if (a<b):
 print "a less than b"
else: 
 print "a is not less than b"
if (a>b):
 print "a is greater than b"
else: 
 print "a is not greater than b"""

"""python membership operators"""
a="sai"
b=['ss','sri','sai']
if (a in b):
 print "a in b"

"""else if """
p=100
if (p<10):
 print "a is less than 10"
elif(p>10):
 print "a is greater than 10"
else: 
 print "p out of range"

""" while"""
c=1
while (c<10):
 print "c is less than 10:", c
 c=c+1
print c

""" for loop """
planets=['mercury','earth','mars','venus']
for p in planets:
  print "current planets is:",p
  if ('mars' in p):
    break
    print "hello"


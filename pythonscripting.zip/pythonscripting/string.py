#!/usr/bin/python
""" python string"""
"""
a="python"
c=[258]
b=[123,456,'sai','sri']
print a.capitalize()
b.insert(2,200)
print "finallist",b
c.extend(b)
print "extend list",c
"""
"""
str="sai"
def string(str):
  print "string",str  
  return
string(str)"""
x=48
y=32
def fun(x,y):
 add=x+y
 sub=x-y
 mul=x*y
 print "addition is:",add
 print "sub is:",sub
 print "mul is:",mul
 return
fun(x,y)
fun(2,3)
